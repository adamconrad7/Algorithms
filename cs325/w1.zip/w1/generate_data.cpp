#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <fstream>
using namespace std;

int main(){
  srand (time(NULL));
  int n = 20000;
  ofstream of;
  of.open("data.txt");
  of << n << " ";
  for(int i=0; i<n; i++){
    of << rand() % 10000 <<" ";
  }
  of.close();
  return 0;
}
